@extends('adminlte::page')

@section('title', 'AdminLTE')

@section('content_header')
    <h1>Add User</h1>
@stop

@section('content')
<div class="container">
    	<div class="col-md-6">
           
                    <form method="post" action = "{{route('view-user.update',$user->id)}}">
                        <div class="form-group">
                            @csrf
                            @method('PATCH')

                            <label for="name">First Name:</label>
                            <input type="text" class="form-control" name="firstname" value="{{$user->firstname}}"/>

                        </div>
                        <div class="form-group">
                            <label for="price"> Last Name:</label>
                            <input type="text" class="form-control" name="lastname" value="{{$user->lastname}}"/>

                        </div>
                        <div class="form-group">
                            <label for="quantity">Address:</label>
                            <input type="text" class="form-control" name="address" value="{{$user->address}}"/>

                        </div>
                        <div class="form-group">
                            <label for="quantity">Email:</label>
                            <input type="text" class="form-control" name="email" value="{{$user->email}}"/>

                        </div>
                        <div class="form-group">
                            <label for="quantity">Contact:</label>
                            <input type="text" class="form-control" name="contact" value="{{$user->contact}}"/>

                        </div>
                        <button type="submit" class="btn btn-primary">Edit User</button>
                    </form>
               
            </div>
        </div>
@stop