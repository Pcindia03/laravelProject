@extends('adminlte::page')

@section('title', 'AdminLTE')

@section('content_header')
<h2>Product <a href="{{url('cart/addedproducts')}}"><i class='fas fa-cart-plus'></i><span class="badge badge-secondary">
{{$product->count()}}</span></a></h2>    
@stop

@section('content')
<div class="container">

<div class="row">
@foreach($list as $p)



<div class="col-md-2">
<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="images/{{$p->image}}" alt="product image" width="200px" height="200px">
  <div class="card-body">
    <h5 class="card-title">{{$p->name}}</h5>
    <p class="card-text">Price : {{$p->price}}</p>
    <a href="{{route('cart.add',$p->id)}}" class="btn btn-primary">Add to cart</a>
  </div>
</div>
</div>
<div class="col-md-1">
</div>
<!-- <tr>
    <td>{{$p->id}}</td>
    <td>{{$p->name}}</td>
    <td>{{$p->price}}</td>
    <td>
    <button class="btn btn-primary">Add to cart</button></td>
    <td>

         <form action="/admin" method="POST">
            {{csrf_field()}}
            <script
                    src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                    data-key="pk_test_dGClcHYh62iwokRbivBmQmCF"
                    data-amount="2000"
                    data-name="Stripe Demo"
                    data-description="Online course about integrating Stripe"
                    data-image="https://stripe.com/img/documentation/checkout/marketplace.png"
                    data-locale="auto"
                    data-currency="usd">
            </script>
        </form>
    </td>
</tr> -->
@endforeach
</div>


  

       

</div>
@stop
