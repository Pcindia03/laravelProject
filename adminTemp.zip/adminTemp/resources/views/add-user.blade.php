@extends('adminlte::page')

@section('title', 'AdminLTE')

@section('content_header')
    <h1>Add User</h1>
@stop

@section('content')
<div class="container">
    	<div class="col-md-6">
           
                    <form method="post" action = "{{route('view-user.store')}}">
                        <div class="form-group">
                            @csrf
                            <label for="name">First Name:</label>
                            <input type="text" class="form-control" name="firstname" />
                            @if ($errors->has('firstname')) <div class="alert alert-danger">{{ $errors->first('firstname') }}</div> @endif <br>

                        </div>
                        <div class="form-group">
                            <label for="price"> Last Name:</label>
                            <input type="text" class="form-control" name="lastname"/>
                            @if ($errors->has('lastname')) <div class="alert alert-danger">{{ $errors->first('lastname') }}</div> @endif <br>

                        </div>
                        <div class="form-group">
                            <label for="quantity">Address:</label>
                            <input type="text" class="form-control" name="address"/>
                            @if ($errors->has('address')) <div class="alert alert-danger">{{ $errors->first('address') }}</div> @endif <br>

                        </div>
                        <div class="form-group">
                            <label for="quantity">Email:</label>
                            <input type="text" class="form-control" name="email"/>
                            @if ($errors->has('email')) <div class="alert alert-danger">{{ $errors->first('email') }}</div> @endif <br>

                        </div>
                        <div class="form-group">
                            <label for="quantity">Contact:</label>
                            <input type="text" class="form-control" name="contact"/>
                            @if ($errors->has('contact')) <div class="alert alert-danger">{{ $errors->first('contact') }}</div> @endif <br>

                        </div>
                        <button type="submit" class="btn btn-primary">Add User</button>
                    </form>
               
            </div>
        </div>
@stop