@extends('adminlte::page')

@section('title', 'AdminLTE')

@section('content_header')
    <h1>View User List</h1>
@stop

@section('content')
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <a href="{{ route('view-user.create') }}"><button class="btn btn-primary">Add User</button></a>
  <div class="uper">
    @if(session()->get('success'))
      <div class="alert alert-success">
        {{ session()->get('success') }}  
      </div><br />
    @endif
  </div>
  <table class="table table-striped" id="table">
    <thead>
        <tr>
          <td>S.No.</td>
          <td>First Name</td>
          <td>Last Name</td>
          <td>Email</td>
          <td>Address</td>
          <td>Contact</td>
          
          <td>Action</td>
         
        </tr>
    </thead>
    
  </table>
@stop
@section('js')
<script src="//code.jquery.com/jquery.js"></script>

<script src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>

<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<script>

$(function() {

  $.ajaxSetup({

headers: {

    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

}

});

  var table =  $('#table').DataTable({

        processing: true,

        serverSide: true,

        ajax: '{!! route('view-user.index') !!}',

        columns: [

            {data: 'id', name: 'id'},

            { data: 'firstname', name: 'firstname' },

            { data: 'lastname', name: 'lastname' },

            { data: 'email', name: 'email' },

            { data: 'address', name: 'address' },

            { data: 'contact', name: 'contact' },

            {data: 'action', name: 'action', orderable: false, searchable: false},



           

        ]

    });

    $('body').on('click', '.deleteProduct', function () {

     

var user_id = $(this).data("id");

confirm("Are You sure want to delete !");



$.ajax({

    method: "DELETE",

    url: "view-user/"+user_id,

    success: function (res) {

        table.draw();

    },

    error: function (res) {

        console.log('Error:', res);

    }

});

});

});

</script>
@stop



