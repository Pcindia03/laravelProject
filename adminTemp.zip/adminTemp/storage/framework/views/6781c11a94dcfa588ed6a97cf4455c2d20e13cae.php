<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
<h2>Product <a href="<?php echo e(url('cart/addedproducts')); ?>"><i class='fas fa-cart-plus'></i><span class="badge badge-secondary">
<?php echo e($product->count()); ?></span></a></h2>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

<div class="row">
<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



<div class="col-md-2">
<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="images/<?php echo e($p->image); ?>" alt="product image" width="200px" height="200px">
  <div class="card-body">
    <h5 class="card-title"><?php echo e($p->name); ?></h5>
    <p class="card-text">Price : <?php echo e($p->price); ?></p>
    <a href="<?php echo e(route('cart.add',$p->id)); ?>" class="btn btn-primary">Add to cart</a>
  </div>
</div>
</div>
<div class="col-md-1">
</div>
<!-- <tr>
    <td><?php echo e($p->id); ?></td>
    <td><?php echo e($p->name); ?></td>
    <td><?php echo e($p->price); ?></td>
    <td>
    <button class="btn btn-primary">Add to cart</button></td>
    <td>

         <form action="/admin" method="POST">
            <?php echo e(csrf_field()); ?>

            <script
                    src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                    data-key="pk_test_dGClcHYh62iwokRbivBmQmCF"
                    data-amount="2000"
                    data-name="Stripe Demo"
                    data-description="Online course about integrating Stripe"
                    data-image="https://stripe.com/img/documentation/checkout/marketplace.png"
                    data-locale="auto"
                    data-currency="usd">
            </script>
        </form>
    </td>
</tr> -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


  

       

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>