<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Add User</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    	<div class="col-md-6">
           
                    <form method="post" action = "<?php echo e(route('view-user.update',$user->id)); ?>">
                        <div class="form-group">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>

                            <label for="name">First Name:</label>
                            <input type="text" class="form-control" name="firstname" value="<?php echo e($user->firstname); ?>"/>

                        </div>
                        <div class="form-group">
                            <label for="price"> Last Name:</label>
                            <input type="text" class="form-control" name="lastname" value="<?php echo e($user->lastname); ?>"/>

                        </div>
                        <div class="form-group">
                            <label for="quantity">Address:</label>
                            <input type="text" class="form-control" name="address" value="<?php echo e($user->address); ?>"/>

                        </div>
                        <div class="form-group">
                            <label for="quantity">Email:</label>
                            <input type="text" class="form-control" name="email" value="<?php echo e($user->email); ?>"/>

                        </div>
                        <div class="form-group">
                            <label for="quantity">Contact:</label>
                            <input type="text" class="form-control" name="contact" value="<?php echo e($user->contact); ?>"/>

                        </div>
                        <button type="submit" class="btn btn-primary">Edit User</button>
                    </form>
               
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>