<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>View User List</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <a href="<?php echo e(route('view-user.create')); ?>"><button class="btn btn-primary">Add User</button></a>
  <div class="uper">
    <?php if(session()->get('success')): ?>
      <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>  
      </div><br />
    <?php endif; ?>
  </div>
  <table class="table table-striped" id="table">
    <thead>
        <tr>
          <td>S.No.</td>
          <td>First Name</td>
          <td>Last Name</td>
          <td>Email</td>
          <td>Address</td>
          <td>Contact</td>
          
          <td>Action</td>
         
        </tr>
    </thead>
    
  </table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="//code.jquery.com/jquery.js"></script>

<script src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>

<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<script>

$(function() {

  $.ajaxSetup({

headers: {

    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

}

});

  var table =  $('#table').DataTable({

        processing: true,

        serverSide: true,

        ajax: '<?php echo route('view-user.index'); ?>',

        columns: [

            {data: 'id', name: 'id'},

            { data: 'firstname', name: 'firstname' },

            { data: 'lastname', name: 'lastname' },

            { data: 'email', name: 'email' },

            { data: 'address', name: 'address' },

            { data: 'contact', name: 'contact' },

            {data: 'action', name: 'action', orderable: false, searchable: false},



           

        ]

    });

    $('body').on('click', '.deleteProduct', function () {

     

var user_id = $(this).data("id");

confirm("Are You sure want to delete !");



$.ajax({

    method: "DELETE",

    url: "view-user/"+user_id,

    success: function (res) {

        table.draw();

    },

    error: function (res) {

        console.log('Error:', res);

    }

});

});

});

</script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>