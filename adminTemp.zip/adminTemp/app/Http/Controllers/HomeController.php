<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\cart;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }
    public function addUser(Request $request){
        echo $request;
        die;
    }

    public function addToCart($id){
        $cart = new cart;
        $cart->product_id = $id;
        $cart->save();
        return redirect('/stripe')->with('Product added to cart');
    }

    public function showCart(){
      $cartItems = cart::with('product')->get();

    return view('cart',compact('cartItems'));
    }
}
