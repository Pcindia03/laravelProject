<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\product;
use App\cart;
use Session;
use Stripe;





class StripePaymentController extends Controller
{
  public function stripe(){
     $product = cart::all();
     foreach($product as $p){
       $id[] = $p->product_id;
     }
     $list = product::whereNotIn('id',$id)->get();

    return view('stripe',compact('list','product'));
  }

  public function admin(Request $request)
  {
    
    Stripe\Stripe::setApiKey(env('STRIPE_SECRET_KEY'));
        Stripe\Charge::create ([
                
                "amount" => $request->price * 100,
                "currency" => "usd",
                "source" => $request->stripeToken,
                "description" => "Test payment " 
        ]);
  
        Session::flash('success', 'Payment successful!');
          
        return back();
  }
      
}  


 

