<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Yajra\Datatables\Datatables;

use App\user_crud;

class userController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function view(){
        return view('view-user');
    }
    public function index()
    {
        
        $users = user_crud::select(['id', 'firstname', 'lastname', 'email', 'address', 'contact']);

        return Datatables::of($users) ->addColumn('action', function ($user) {
            return '<a href="view-user/'.$user->id.'/edit" class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-edit"></i> Edit</a>
            <a href="javascript:void(0)" data-toggle="tooltip"  data-id="'.$user->id.'" data-original-title="Delete" class="btn btn-danger btn-sm deleteProduct"><i class="glyphicon glyphicon-trash"></i>Delete</a>';
        })
     ->make(true);
    }
    public function getUser(){
      
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('add-user');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try{
        $data = $request->all();
       
        $validatedData = $request -> validate([
            'firstname' => 'required|max:255',
            'lastname' => 'required|max:255',
            'address' => 'required|max:255',
            'email' => 'required|max:255',
            'contact' => 'required|numeric'
        ]);
        $user = user_crud::create($data);
        if($user){        
          return redirect('/admin/get-user')->with('success','user Added Successfully');
        } else {
            die('not inserted');
        }
        } catch (Exception $e){
            die($e->getMessage());
        } 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = user_crud :: findOrFail($id);
        return view('edit-user',compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        $validatedData = $request->validate([
            'firstname' => 'required|max:255',
            'lastname' => 'required|max:255',
            'address' => 'required|max:255',
            'email' => 'required|max:255',
            'contact' => 'required|numeric'
        ]);
        $editUser = user_crud::whereId($id)->update($validatedData);
        return redirect('/admin/get-user')->with('success','user is successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
       
        $user = user_crud::findOrFail($id);
        $user->delete();

        return response()->json(['success'=>'User deleted successfully.']);
    }
}
