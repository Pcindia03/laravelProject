<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class user_crud extends Model
{
    protected $table = 'user_cruds';

    protected $fillable = ['firstname','lastname','address','email','contact'];
}
